
import React, { useState } from 'react';
import { TOOLS } from './constants';
import { Tool } from './types';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Award, MapPin, MousePointer2, Briefcase } from 'lucide-react';

const App: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);

  // Group tools by which side of the knife they emerge from
  const leftTools = TOOLS.filter(t => ['mentorship', 'navigator', 'leader'].includes(t.id));
  const rightTools = TOOLS.filter(t => ['toolkit', 'prioritization', 'pivot', 'small-market'].includes(t.id));

  // Placeholder portrait
  const LinnAvatar = () => (
    <div className="w-full h-full bg-rose-100 flex items-center justify-center relative overflow-hidden">
      <div className="absolute bottom-0 w-16 h-16 bg-rose-300 rounded-full blur-xl opacity-50"></div>
      <div className="text-rose-500 font-serif-display text-4xl select-none">LM</div>
    </div>
  );

  const renderToolGraphic = (tool: Tool) => {
    const iconSize = "w-4 h-4";
    const baseColorClass = tool.color.split(' ')[0];
    
    switch (tool.id) {
      case 'prioritization': // Blade
        return (
          <div className="relative h-44 w-12 flex flex-col items-center origin-bottom">
            <div className={`h-36 w-10 ${baseColorClass} rounded-tr-[100%] rounded-tl-[10%] rounded-b-lg border border-white/40 shadow-xl flex items-center justify-center`}>
               <div className="bg-white/40 p-2 rounded-full mb-12">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
            <div className="w-4 h-8 bg-gray-300 -mt-1 rounded-b-full"></div>
          </div>
        );
      case 'mentorship': // Brush
        return (
          <div className="relative h-44 w-14 flex flex-col items-center origin-bottom">
            <div className={`h-20 w-14 ${baseColorClass} rounded-t-2xl border border-white/40 shadow-lg relative flex flex-col items-center justify-center`}>
               <div className="bg-white/40 p-1.5 rounded-full z-10">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
            <div className="w-14 h-4 bg-gray-200/80 border-x border-white/30"></div>
            <div className="w-8 h-20 bg-[#eadcbd] rounded-b-full border border-white/30 shadow-md"></div>
          </div>
        );
      case 'leader': // Ruler
        return (
          <div className="relative h-52 w-10 flex flex-col items-center origin-bottom">
            <div className={`h-48 w-9 ${baseColorClass} rounded-md border border-white/40 shadow-lg relative flex flex-col items-center py-6`}>
              <div className="absolute left-0 top-0 bottom-0 w-2 flex flex-col justify-between py-2 opacity-30">
                {[...Array(12)].map((_, i) => <div key={i} className="w-full h-[1px] bg-white"></div>)}
              </div>
              <div className="bg-white/40 p-2 rounded-full">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
            <div className="w-4 h-4 bg-gray-300 rounded-b-full"></div>
          </div>
        );
      case 'navigator': // Compass Arm
        return (
          <div className="relative h-48 w-10 flex flex-col items-center origin-bottom">
            <div className={`h-44 w-8 ${baseColorClass} rounded-full border border-white/40 shadow-lg flex items-center justify-center`}>
               <div className="bg-white/40 p-2 rounded-full mb-12">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
            <div className="w-4 h-4 bg-gray-300 rounded-b-full"></div>
          </div>
        );
      case 'small-market': // Magnifier
        return (
          <div className="relative h-44 w-20 flex flex-col items-center origin-bottom">
            <div className={`w-20 h-20 rounded-full border-[5px] border-white bg-white/30 backdrop-blur-md shadow-xl flex items-center justify-center overflow-hidden`}>
               <div className={`absolute inset-0 ${baseColorClass} opacity-20`}></div>
               <div className="bg-white/90 p-2.5 rounded-full shadow-inner z-10">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: "w-6 h-6" })}</div>
            </div>
            <div className="w-3 h-24 bg-gray-300 rounded-b-full border border-white/20 shadow-md"></div>
          </div>
        );
      case 'toolkit': // Wrench
        return (
          <div className="relative h-40 w-14 flex flex-col items-center origin-bottom">
            <div className={`h-12 w-14 ${baseColorClass} border border-white/40 shadow-lg rounded-t-xl flex items-center justify-center`}>
               <div className="w-8 h-8 bg-[#fcfaf6] rounded-full border border-white/20"></div>
            </div>
            <div className={`h-28 w-9 ${baseColorClass} border-x border-white/40 shadow-lg flex items-center justify-center`}>
               <div className="bg-white/40 p-2 rounded-full mb-8">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
          </div>
        );
      case 'pivot': // Spring
        return (
          <div className="relative flex flex-col items-center h-48 origin-bottom">
            <div className="w-14 h-32 flex flex-col items-center justify-center -space-y-1">
               {[...Array(6)].map((_, i) => (
                 <div key={i} className={`h-5 w-14 border border-white/50 rounded-full ${baseColorClass} shadow-sm`}></div>
               ))}
            </div>
            <div className={`w-12 h-12 rounded-full ${baseColorClass} border border-white/40 shadow-xl flex items-center justify-center -mt-2`}>
              <div className="bg-white/40 p-2 rounded-full">{React.cloneElement(tool.icon as React.ReactElement<any>, { className: iconSize })}</div>
            </div>
          </div>
        );
      default:
        return <div className={`h-24 w-12 ${baseColorClass} rounded-xl shadow-xl`} />;
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#fcfaf6] flex flex-col items-center relative selection:bg-rose-100 overflow-x-hidden">
      
      {/* Dynamic Background */}
      <div className="fixed inset-0 pointer-events-none opacity-40 z-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-100 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-100 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2"></div>
      </div>

      <header className="pt-16 pb-8 text-center z-10 px-4">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-1.5 bg-white/80 backdrop-blur-md px-4 py-1.5 rounded-full border border-gray-100 shadow-sm mb-6"
        >
          <Award className="w-3.5 h-3.5 text-rose-500" />
          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
            Linn Marie • APMM Alumni Fellow Candidate
          </span>
        </motion.div>
        
        <h1 className="flex flex-col items-center text-5xl md:text-7xl lg:text-8xl font-bold text-gray-900 tracking-tighter leading-none font-serif-display max-w-4xl mx-auto">
          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>Linn Marie</motion.span>
          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="text-rose-500 italic md:-mt-2">the Swiss army knife.</motion.span>
        </h1>
        
        <motion.p 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ delay: 0.6 }}
          className="text-gray-500 font-medium mt-6 text-base md:text-lg max-w-2xl mx-auto leading-relaxed border-t border-gray-100 pt-6"
        >
          Why I am a perfect fit for the APMM Mentorship program
        </motion.p>
      </header>

      {/* THE POCKET KNIFE STAGE */}
      <div className="w-full flex items-center justify-center relative py-24 md:py-32">
        <div className="relative w-full max-w-4xl h-[400px] md:h-[500px] flex items-center justify-center">
          
          {/* HANDLE BODY */}
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative z-40 w-[320px] md:w-[450px] h-[120px] md:h-[160px] bg-white rounded-full shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] border border-gray-100 flex items-center px-6 md:px-10 group overflow-hidden"
          >
            <div className="flex items-center gap-4 md:gap-6 z-10">
              <div className="w-16 h-16 md:w-24 md:h-24 rounded-full border-2 border-rose-50 overflow-hidden shadow-sm group-hover:scale-105 transition-transform duration-500 flex-shrink-0">
                <LinnAvatar />
              </div>
              <div className="flex flex-col">
                <h2 className="text-2xl md:text-4xl font-bold text-gray-900 font-serif-display leading-none">The 360° Toolkit</h2>
                <p className="text-[8px] md:text-[10px] font-bold text-rose-400 uppercase tracking-[0.3em] mt-2 md:mt-3">Swiss-Based Agility</p>
              </div>
            </div>

            <div className="absolute left-6 md:left-8 top-1/2 -translate-y-1/2 w-6 h-6 md:w-8 md:h-8 bg-gray-50 rounded-full border border-gray-200 shadow-inner flex items-center justify-center">
              <div className="w-2 h-2 md:w-2.5 md:h-2.5 bg-gray-300 rounded-full"></div>
            </div>
            <div className="absolute right-6 md:right-8 top-1/2 -translate-y-1/2 w-6 h-6 md:w-8 md:h-8 bg-gray-50 rounded-full border border-gray-200 shadow-inner flex items-center justify-center">
              <div className="w-2 h-2 md:w-2.5 md:h-2.5 bg-gray-300 rounded-full"></div>
            </div>
            
            <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-transparent to-black/[0.03] rounded-full pointer-events-none"></div>
          </motion.div>

          {/* LEFT TOOLS */}
          <div className="absolute left-1/2 top-1/2 -translate-x-[140px] md:translate-x-[calc(-225px+32px)] translate-y-0 z-30 pointer-events-none">
            {leftTools.map((tool, index) => {
              const angles = [-160, -115, -70];
              const targetAngle = angles[index];
              return (
                <motion.div
                  key={tool.id}
                  initial={{ rotate: 0 }}
                  animate={{ rotate: targetAngle }}
                  style={{ originX: '50%', originY: '100%' }}
                  className="absolute bottom-0 left-0"
                >
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    onClick={() => setSelectedTool(tool)}
                    className="pointer-events-auto cursor-pointer outline-none mb-4"
                  >
                    {renderToolGraphic(tool)}
                  </motion.button>
                </motion.div>
              );
            })}
          </div>

          {/* RIGHT TOOLS */}
          <div className="absolute left-1/2 top-1/2 translate-x-[140px] md:translate-x-[calc(225px-32px)] translate-y-0 z-30 pointer-events-none">
            {rightTools.map((tool, index) => {
              const angles = [160, 115, 70, 25];
              const targetAngle = angles[index];
              return (
                <motion.div
                  key={tool.id}
                  initial={{ rotate: 0 }}
                  animate={{ rotate: targetAngle }}
                  style={{ originX: '50%', originY: '100%' }}
                  className="absolute bottom-0 right-0"
                >
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    onClick={() => setSelectedTool(tool)}
                    className="pointer-events-auto cursor-pointer outline-none mb-4"
                  >
                    {renderToolGraphic(tool)}
                  </motion.button>
                </motion.div>
              );
            })}
          </div>

          <div className="absolute bottom-[100px] md:bottom-[140px] left-1/2 -translate-x-1/2 w-[300px] md:w-[400px] h-[30px] bg-black/[0.04] blur-2xl rounded-full -z-10"></div>
        </div>
      </div>

      {/* DETAIL MODAL */}
      <AnimatePresence>
        {selectedTool && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6 bg-white/20 backdrop-blur-xl">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="w-full max-w-lg bg-white rounded-[2rem] md:rounded-[3rem] shadow-[0_50px_100px_-30px_rgba(0,0,0,0.2)] border border-gray-100 p-8 md:p-12 relative overflow-hidden"
            >
              <div className="max-h-[80vh] overflow-y-auto pr-2 custom-scrollbar">
                <button 
                  onClick={() => setSelectedTool(null)}
                  className="absolute top-6 right-6 md:top-10 md:right-10 p-3 rounded-full hover:bg-gray-50 transition-colors text-gray-300 hover:text-gray-900 z-10"
                >
                  <X className="w-6 h-6" />
                </button>
                
                <div className="flex flex-col gap-6 md:gap-8">
                  <div className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl md:rounded-3xl shadow-sm ${selectedTool.color.split(' ')[0]} flex items-center justify-center border border-white/60`}>
                    {React.cloneElement(selectedTool.icon as React.ReactElement<any>, { className: "w-8 h-8 md:w-10 md:h-10" })}
                  </div>
                  
                  <div className="space-y-4">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{selectedTool.category} Value</p>
                    <h3 className="text-3xl md:text-4xl font-bold text-gray-900 font-serif-display leading-tight">{selectedTool.title}</h3>
                    <p className="text-rose-500 font-bold text-sm tracking-wide">{selectedTool.subtitle}</p>
                    <p className="text-gray-600 leading-relaxed text-base md:text-lg pt-4">{selectedTool.content}</p>
                  </div>

                  <button 
                    onClick={() => setSelectedTool(null)}
                    className="mt-6 md:mt-8 w-full bg-gray-900 text-white py-4 md:py-5 rounded-xl md:rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-rose-500 transition-colors shadow-lg active:scale-[0.98]"
                  >
                    Return to Toolkit
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Info Bar */}
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="w-full max-w-3xl mb-12 z-10 px-4"
      >
        <div className="bg-white/95 backdrop-blur-2xl p-6 rounded-[2rem] md:rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col md:flex-row items-center justify-around gap-6 md:gap-8">
          <div className="flex items-center gap-4">
             <Briefcase className="w-5 h-5 text-rose-500" />
             <div>
               <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Experience</p>
               <p className="text-xl font-bold text-gray-800 font-serif-display">4 Roles in 4 Years</p>
             </div>
          </div>
          <div className="hidden md:block w-[1px] h-10 bg-gray-100"></div>
          <div className="flex items-center gap-4">
             <MapPin className="w-5 h-5 text-blue-400" />
             <div>
               <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Base Market</p>
               <p className="text-xl font-bold text-gray-800 font-serif-display">Switzerland</p>
             </div>
          </div>
        </div>
      </motion.div>

      <footer className="pb-12 opacity-30 flex items-center gap-2">
        <MousePointer2 className="w-3 h-3" />
        <span className="text-[9px] font-bold uppercase tracking-widest">Click any component to expand Linn Marie's skillset</span>
      </footer>
    </div>
  );
};

export default App;
