
import { ReactNode } from 'react';

export interface Tool {
  id: string;
  title: string;
  subtitle: string;
  content: string;
  icon: ReactNode;
  color: string;
  category: 'Why' | 'Achieve' | 'Challenge';
}

export interface Position {
  x: number;
  y: number;
}
