
import React from 'react';
import { 
  Compass, 
  Scissors, 
  Paintbrush, 
  Ruler, 
  Search, 
  RotateCw, 
  Settings 
} from 'lucide-react';
import { Tool } from './types';

export const TOOLS: Tool[] = [
  {
    id: 'mentorship',
    title: 'Support Catalyst',
    subtitle: 'Mentorship & Lightbulb Moments',
    content: 'Mentored 3 international students during COVID and currently guiding 2 apprentices in Switzerland. I find my greatest energy in seeing others find their "lightbulb moments."',
    icon: <Paintbrush className="w-6 h-6" />,
    color: 'bg-rose-100 text-rose-600 border-rose-200',
    category: 'Why'
  },
  {
    id: 'navigator',
    title: 'Culture Navigator',
    subtitle: 'Turning Intensity into Foundation',
    content: 'A huge believer in the APMM community. I want to be the "navigator" I needed: someone to help turn the first-year intensity into a solid career foundation.',
    icon: <Compass className="w-6 h-6" />,
    color: 'bg-blue-100 text-blue-600 border-blue-200',
    category: 'Why'
  },
  {
    id: 'small-market',
    title: 'Agility Lens',
    subtitle: 'The "Smaller Market" Superpower',
    content: 'Empowering the edge. Being the "only one" in Switzerland is a superpower for agility, not a barrier. Helping satellite offices realize their massive platform for impact.',
    icon: <Search className="w-6 h-6" />,
    color: 'bg-emerald-100 text-emerald-600 border-emerald-200',
    category: 'Achieve'
  },
  {
    id: 'toolkit',
    title: '360° Toolkit',
    subtitle: 'The "Swiss Army Knife" Approach',
    content: 'Navigated 4 roles in 4 years (from Scaled Programs to PMM). Helping trainees build a 360-degree toolkit so they can pivot between marketing gears with confidence.',
    icon: <Settings className="w-6 h-6" />,
    color: 'bg-purple-100 text-purple-600 border-purple-200',
    category: 'Achieve'
  },
  {
    id: 'prioritization',
    title: 'Hero Project Blade',
    subtitle: 'Ruthless Prioritization',
    content: 'A sounding board for focus. Filtering out noise to help APMMs focus on "hero projects" that actually move the needle for their market and Google’s broader goals.',
    icon: <Scissors className="w-6 h-6" />,
    color: 'bg-amber-100 text-amber-600 border-amber-200',
    category: 'Challenge'
  },
  {
    id: 'pivot',
    title: 'Pivot Steady',
    subtitle: 'Navigating the Generalist Paradox',
    content: 'Teaching how to stay steady when priorities change. Helping APMMs navigate "the pivot" and maintain sustainable, high-quality results amidst high volumes.',
    icon: <RotateCw className="w-6 h-6" />,
    color: 'bg-indigo-100 text-indigo-600 border-indigo-200',
    category: 'Challenge'
  },
  {
    id: 'leader',
    title: 'Adaptive Leader',
    subtitle: 'Growth as a Support System',
    content: 'I see this role as a way to challenge my own leadership style. I am eager to learn and grow as a mentor to become the best possible support system.',
    icon: <Ruler className="w-6 h-6" />,
    color: 'bg-teal-100 text-teal-600 border-teal-200',
    category: 'Why'
  }
];
